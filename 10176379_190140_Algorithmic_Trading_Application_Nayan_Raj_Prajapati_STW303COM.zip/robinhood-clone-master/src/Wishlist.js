import React from 'react'

function Wishlist({ stocks }) {
    return (
        <div>
            
        </div>
    )
}

export default Wishlist
