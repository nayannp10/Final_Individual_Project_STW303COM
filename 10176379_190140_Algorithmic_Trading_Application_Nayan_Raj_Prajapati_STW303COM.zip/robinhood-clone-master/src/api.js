import axios from "axios";

const key = "bv1uf4v48v6o5ed6h88g";

export { key };
